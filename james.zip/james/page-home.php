<?php
/**
 * Template Name: Home
 *
 */

get_header(); ?>

<div class="motopress-wrapper">
	<div class="cnt_100" style="margin-top: 15px;  padding-bottom: 10em;">
		<div data-motopress-type="loop" data-motopress-loop-file="loop/loop-page-home.php">
			<?php get_template_part("loop/loop-page-home"); ?>
		</div>
	</div>
</div>
<?php echo do_shortcode('[recent_project limit=3]');?>
<?php get_footer(); ?>
