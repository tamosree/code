<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

	<footer id="colophon" role="contentinfo" class="motopress-wrapper footer">
		<div data-motopress-wrapper-file="wrapper/wrapper-footer.php" data-motopress-wrapper-type="footer" data-motopress-id="<?php echo uniqid() ?>">
			<?php get_template_part('wrapper/wrapper-footer'); ?>
		</div>
	</footer>
</div><!-- #motopress-main -->

<?php wp_footer(); ?>

</body>
</html>
