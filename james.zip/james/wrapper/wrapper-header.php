<?php
/**
* Wrapper Name: Header
*/
?>
<div class="row">
	<div data-motopress-type="static" data-motopress-static-file="static/static-header.php">
		<?php get_template_part("static/static-header"); ?>
	</div>
</div>
<?php if(is_home() || is_front_page()){ ?>
<div class="twelve">
	<div data-motopress-type="static" data-motopress-static-file="static/static-slider.php">
		<?php get_template_part("static/static-slider"); ?>
	</div>
</div>
<?php }?>