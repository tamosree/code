<?php
/**
* Wrapper Name: Footer
*/
?>
<div class="cnt_100">
    <div class="row" style="margin-top: 10em;">
		<div data-motopress-type="static" data-motopress-static-file="static/static-footer.php">
			<?php get_template_part("static/static-footer"); ?>
		</div>
	</div>
</div>
<div class="cnt_100" style="padding-top: 2em; background-color: #E6E6E6 !important;">
	<div class="row" >
		<div data-motopress-type="static" data-motopress-static-file="static/static-footer-copyright.php">
			<?php get_template_part("static/static-footer-copyright"); ?>
		</div>
	</div>
</div>