/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

jQuery.noConflict();
jQuery(document).ready(function(){ 
   
    
    jQuery(".btnemail").click(function() {
        if(jQuery('#name_user').val().length>0 && checkemail(jQuery('#email_user').val()) && jQuery('#message_user').val().length>0){
            
            jQuery.post("sendemail.php",
            {               
                email: jQuery('#email_user').val(),                
                message: jQuery('#message_user').val(),
                tel: jQuery('#tel_user').val(),
                company: jQuery('#company_user').val(),
                name:jQuery('#name_user').val()
            },
            function(data){
                jQuery('#message_form').html( 'Your mesage has been sent correctly, we will be in touch as soon as possible.');
            }
            ); 
        }else{       
            jQuery('#message_form').html('Please provide the correct information.Check your email, name and message. Thanks');

        }       
    });
});

function checkemail(str){

    var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
    if (filter.test(str)) {
        return true;
    } else{
        return false;
    }
}