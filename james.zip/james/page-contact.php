<?php
/**
 * Template Name: Contact
 *
 */

get_header(); ?>

<div class="motopress-wrapper">
	<div class="container">
		<div class="row">
			<div class="twelve columns" data-motopress-type="loop" data-motopress-loop-file="loop/loop-page-contact.php">
				<?php get_template_part("loop/loop-page-contact"); ?>
			</div>			
		</div>
	</div>
</div>

<?php get_footer(); ?>
