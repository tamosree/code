<?php
// recent projects on home page
function recent_project_shortcode($atts){
	extract(shortcode_atts(array( // a few default values
		'limit' => '1',
		'type' => 'project')
		, $atts));

	$atts	=	array( // a few default values
	'showposts' => $limit,
	'post_type' => $type,
	'meta_query' => array(
		array(
			'key'     => 'home_featured_projects',
			'value'   => 'Yes'
		),
	));

  global $post;

	$out = '
			<div class="cnt_100" style="padding-top: 2em; padding-bottom: 2em; background-color: #E6E6E6 !important;">
				<div class="row" >
					<div class="remove twelve columns font36" style="color: #4A4C4B;">
						<span style="font-weight: 300;">RECENT PROJECTS</span>  
					</div>
					<div class="showmobile twelve columns font36" style="color: #4A4C4B;">
						<span style="font-weight: 300;">RECENT PROJECTS</span>  
					</div>
					<div class="cnt_100" style="margin-top: 20px;  background-color: #E6E6E6 !important;">
					';

	$posts = new WP_Query($atts);
	$i=1;
    if ($posts->have_posts())
        while ($posts->have_posts()):
            $posts->the_post();
			$project_text								=	apply_filters('the_content', $post->post_content);
			$project_text								=	wp_trim_words( $project_text, 100);
			if (has_post_thumbnail(  )) :
				$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'homepage-thumb' );
			endif;

            $img_hover_jquery="'.h".$i."'";
            $img_hover_css="h".$i;
			$out.='	
						<div class="six columns" style="cursor: pointer;position: relative;" onclick="location.href = '.get_permalink().'">
							<img src="'.$featured_image[0].'" onmouseover="$('.$img_hover_jquery.').css(\'width\',$(this).width());$('.$img_hover_jquery.').css(\'height\',$(this).height());$('.$img_hover_jquery.').fadeIn(200);" />
							<div class="cnt_100" style="position: absolute; top:0;  background-color: #E6E6E6 !important;" >
								<img src="'.get_template_directory_uri().'/images/hover_project.png" class="'.$img_hover_css.'" style="display: none;" onmouseout="$('.$img_hover_jquery.').fadeOut(200);"/>
							</div>
							<div class="cnt_100 font24" style="color: #4A4C4B; margin: 10px 0 20px 0;  background-color: #E6E6E6 !important;">
								<a href="'.get_permalink().'" title="' . get_the_title() . '">'.get_the_title() .'</a>
							</div>
						</div>';
			
			$i++;
			/* these arguments will be available from inside $content
			get_permalink()  
			get_the_content()
			get_the_category_list(', ')
			get_the_title()
			and custom fields
			get_post_meta($post->ID, 'field_name', true);
		*/
		endwhile;
	else
		return; // no posts found

	$out.='		</div>
            </div>
        </div>';


  wp_reset_query();
  return html_entity_decode($out);
}
add_shortcode('recent_project', 'recent_project_shortcode');

function footer_form_shortcode(){
	$out.='
		<div class="six columns">
			<form action="" id="sendemailform">
                    <div class="cnt_100">
                        <input id="name_user" type="text" value="NAME*" class="font24 ds" onfocus="if(this.value==this.defaultValue)this.value=\'\';" onblur="if(this.value==\'\')this.value=this.defaultValue;"/>
                    </div> 
                    <div class="cnt_100">
                        <input id="company_user" type="text" value="COMPANY" class="font24 ds" onfocus="if(this.value==this.defaultValue)this.value=\'\';" onblur="if(this.value==\'\')this.value=this.defaultValue;"/>
                    </div>
                    <div class="cnt_100">
                        <input id="email_user" type="text" value="EMAIL*" class="font24 ds" onfocus="if(this.value==this.defaultValue)this.value=\'\';" onblur="if(this.value==\'\')this.value=this.defaultValue;"/>
                    </div> 
                    <div class="cnt_100">
                        <input id="tel_user" type="text" value="TEL" class="font24 ds" onfocus="if(this.value==this.defaultValue)this.value=\'\';" onblur="if(this.value==\'\')this.value=this.defaultValue;"/>
                    </div> 
                    <div class="cnt_100">
                        <textarea id="message_user" name="message" type="text" class="font24 ds" onfocus="if(this.value==this.defaultValue)this.value=\'\';" onblur="if(this.value==\'\')this.value=this.defaultValue;">MESSAGE*</textarea>
                    </div>                            
                </form>
                <div style="width: 65%; float: left;color: #4A4C4B;" class="font18">
                    <div style="padding-right: 20px;" id="message_form">
                       &nbsp;
                    </div>
                </div>
                <div style="width: 35%; float: left;">
                    <div class="cnt_100" style="float: right;">
                        <div class="btnemail font24 ds"><b>SEND</b></div>
                    </div>
                </div>
            </div>';
	return html_entity_decode($out);	
}
add_shortcode('footer_form', 'footer_form_shortcode');
add_filter('widget_text', 'do_shortcode');
