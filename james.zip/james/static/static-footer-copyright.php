<?php
/**
* Static Name: Footer Copyright block
*/
?>

		<div class="five columns">
			<div class="spacer_light"></div>
		</div>
		<!-- BEGIN Footer LOGO -->
		<div class="two columns font24"  style="color: #4A4C4B;">
			<img class="remove" style=" margin-left: 25%;width: 50%;" src="<?php echo bloginfo('stylesheet_directory'); ?>/images/james_co_logo_2.png"/> 
			<img class="showmobile" style=" margin-left: 37.5%;width: 25%;" src="<?php echo bloginfo('stylesheet_directory'); ?>/images/james_co_logo_2.png"/> 
		</div>
		<!-- END Footer LOGO -->
		<div class="five columns">
			<div class="spacer_light"></div>
		</div>
		<div class="twelve columns tcenter" style="margin-top: 10px; padding-bottom: 20px;">
			<div class="showmobile font18" style="font-weight: 300;">
				&copy; 2013 Jamesco Pty Ltd </br></br>
				<a href="<?php echo site_url('/privacy-policy/')?>">Privacy Policy</a></br></br>
				<b>ABN 00011 603 167 951</b>
			</div>
			<div class="remove font12" style="font-weight: 300;">
				&copy; 2013 Jamesco Pty Ltd </br></br>
				<a href="<?php echo site_url('/privacy-policy/')?>">Privacy Policy</a></br></br>
				<b>ABN 000011 603 167 951</b>
			</div>
		</div>
	