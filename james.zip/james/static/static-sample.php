<?php
/**
* Static Name: Sample block
*/
?>
<div>I am Sample Static Block. Replace this code with your content.</div>