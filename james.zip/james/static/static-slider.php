<?php
/**
* Static Name: Slider Block
*/
?>
<div style="margin-top: 10px;">
	<div class="slider-wrapper">
		<?php putRevSlider('homeslider'); ?>
	</div>
</div> 