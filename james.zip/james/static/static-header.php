<?php
/**
* Static Name: Header Block
*/
?>

<div class="row">	
	<div class="twelve columns header-bar font16">
		<nav class="top-bar" data-topbar role="navigation">
			<ul class="title-area">
				<li class="name">
					<h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/james_co_logo.png"/></a></h1>
				</li>
				<!-- Remove the class "menu-icon" to get rid of menu icon. Take out "Menu" to just have icon alone -->
				<li class="toggle-topbar menu-icon"><a href="#"><span>Menu</span></a></li>
			</ul>
			<section class="top-bar-section">
				<?php
				  // Left Nav Section
				 if ( has_nav_menu( 'primary' ) ) {
					  wp_nav_menu( array(
						  'theme_location' => 'primary',
						  'container' => false,
						  'depth' => 0,
						  'items_wrap' => '<ul class="right">%3$s</ul>',
						  'fallback_cb' => false,
						  'walker' => new cornerstone_walker( array(
							  'in_top_bar' => true,
							  'item_type' => 'li'
						  ) ),
					  ) );
					}
                                 
				  ?>
				<!-- Right Nav Section -->
				

		  </section>
		</nav>
	</div>
</div>
