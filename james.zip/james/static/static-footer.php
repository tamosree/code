<?php
/**
* Static Name: Footer block
*/
?>
		
		<div class="five columns">
			<div class="spacer_light"></div>
		</div>
		<div class="two columns font24 tcenter"  style="color: #4A4C4B;">GET IN TOUCH</div>
		<div class="five columns">
			<div class="spacer_light"></div>
		</div>
		<div class="twelve columns tcenter font36"  style="font-weight: 300;color: #4A4C4B;margin-top: 15px;">
			<b> WE ARE ALWAYS LOOKING FOR A CHALLENGE</b> </br>
			Feel free to contact us for any enquiries
		</div>

	    <div class="showmobile twelve columns spacer_light" style="margin: 20px 0px 20px 0px;"></div>
		<div class="remove cnt_100" style="margin-top: 50px;"></div>


		<div class="cnt_100" style="padding-bottom: 10em;">
			<div class="remove three columns font18 tcentermobile" style="color: #4A4C4B;" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-1">
				<?php dynamic_sidebar("footer-sidebar-1"); ?>
			</div>
			<div class="showmobile three columns font24 tcentermobile" style="color: #4A4C4B;" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-1m">
				<?php dynamic_sidebar("footer-sidebar-1"); ?>
			</div>
	
			<div class="showmobile twelve columns spacer_light" style="margin: 30px 0px -10px 0px;"></div>
		
			<div class="remove three columns font18 tcentermobile" style="color: #4A4C4B;" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-2">
				<?php dynamic_sidebar("footer-sidebar-2"); ?>
			</div>
		
			<div class="showmobile three columns font24 tcenter tcentermobile" style="color: #4A4C4B;" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-2m">
				<?php dynamic_sidebar("footer-sidebar-2"); ?>
			</div>
			<div class="showmobile twelve columns spacer_light" style="margin: 20px 0px 30px 0px;"></div>

			<?php dynamic_sidebar("footer-sidebar-form"); ?>

		</div>
