<?php
/**
 * Template Name: Projects
 * Description: A full-width prjoect template
 */
get_header(); ?>

<!-- Add jQuery library -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/fancybox/lib/jquery-1.10.1.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/jquery.easing.min.js"></script>	
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/jquery.mixitup.min.js"></script>
<script type="text/javascript">
	$(function () {
		
		var filterList = {
		
			init: function () {
			
				// MixItUp plugin
				// http://mixitup.io
				$('#portfoliolist').mixitup({
					targetSelector: '.portfolio',
					filterSelector: '.filter',
					effects: ['fade'],
					easing: 'snap',
					// call the hover effect
					onMixEnd: filterList.hoverEffect()
				});				
			
			},
			
			hoverEffect: function () {
			
				// Simple parallax effect
				$('#portfoliolist .portfolio').hover(
					function () {
						$(this).find('.label').stop().animate({bottom: 0}, 200, 'easeOutQuad');
						$(this).find('img').stop().animate({top: -30}, 500, 'easeOutQuad');				
					},
					function () {
						$(this).find('.label').stop().animate({bottom: -40}, 200, 'easeInQuad');
						$(this).find('img').stop().animate({top: 0}, 300, 'easeOutQuad');								
					}		
				);				
			
			}

		};
		
		// Run the show!
		filterList.init();
		
		
	});	
	</script>

<div class="motopress-wrapper">
	<div class="container">
		<div class="row">
			<div class="twelve columns">
			
				<div id="content" class="clearfix full-width-content know_us_template">
					<div id="main" class="clearfix" role="main">
						<!-- oc code start here -->
						<div class="page_content_container">
							<article id="post-<?php the_ID(); ?>">
								<header class="entry-header">
									<h1 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'wp-jurist' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark"><?php the_title(); ?></a></h1>
									<?php if ( 'post' == get_post_type() ) : ?>
										<div class="entry-meta">
											<?php wp_jurist_posted_on(); ?>
										</div><!-- .entry-meta -->
									<?php endif; ?>
								</header><!-- .entry-header -->
								
								
								<div class="entry-content post-content">									
									<div class="row">										
										<ul class="block-grid two-up">
										<?php
												//Setup the query to retrieve the posts that exist under each term
												$posts = get_posts(array(
													'post_type' => 'project',
													'orderby' => 'menu_order',
													'order' =>  'ASC',
													'nopaging' => true
												));
												// Here's the second, nested foreach loop that cycles through the posts associated with this category
												foreach($posts as $post) :
													setup_postdata($post); ////set up post data for use in the loop (enables the_title(), etc without specifying a post ID--as referenced in the stackoverflow link above)
											?>
											<li>
												<?php
													//retrieves the post thumbnail for each post
													$thumb = get_post_thumbnail_id();
													$img_url = wp_get_attachment_url( $thumb,'medium' ); //get full URL to image (use "large" or "medium" if the images too big)
													$image = aq_resize( $img_url, 300, 270, true ); //resize & crop the image using aqua resizer https://github.com/sy4mil/Aqua-Resizer
												?>
												<figure class="work-thumb">
													<a class="th" href="<?php the_permalink()?>" rel="bookmark" title="<?php the_title(); ?>">
													<?php if($image) : ?>
														<img src="<?php echo $image ?>" alt="<?php the_title(); ?> thumb"/>
													<?php else : ?>
														<img class="" src="<?php bloginfo('stylesheet_directory'); ?>/img/small-placeholder.png" alt="placeholder image"> 
										            <?php endif; ?>
													</a>
													<figcaption><h4><a href="<?php the_permalink()?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4></figcaption>
												</figure>
								            </li>
											<?php endforeach; ?>
											</ul>
									</div><!-- .row -->     
								
								</div><!-- .entry-content -->
							</article><!-- #post-<?php the_ID(); ?> -->
						</div>
						<!-- oc code end here -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	<script>
		jQuery(document).ready(function(){
	<?php 	
		for($i=0;$i<count($lightbox_script);$i++){
			//echo "jQuery('.".$lightbox_script[$i]."').colorbox({rel:'".$lightbox_script[$i]."'});";
			//echo "jQuery('.".$lightbox_script[$i]."').fancybox();";
			echo "jQuery('.".$lightbox_script[$i]."')
					.attr('rel', 'gallery')
					.fancybox({
						padding : 0,
						helpers : {
							title: {
								type: 'inside',
								position: 'bottom'
							}
						}
					});";
			}
	?>

			

		});
	</script>
<?php get_footer(); ?>