<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

<div class="motopress-wrapper">
	<div class="container">
		<div class="row">
			<div class="nine columns" data-motopress-type="loop" data-motopress-loop-file="loop/loop-page.php">
				<?php get_template_part("loop/loop-page"); ?>
			</div>
			<div class="three columns" data-motopress-type="static-sidebar" data-motopress-sidebar-file="sidebar.php">
				<?php get_sidebar(); ?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
