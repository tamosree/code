<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300italic,400italic,700italic,400,300,700' rel='stylesheet' type='text/css'>
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	<script>(function(){document.documentElement.className='js'})();</script>

	<?php wp_head(); ?>

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" />

<script type="text/javascript">
jQuery(window).load(function() {
    jQuery('#nivo-slider').nivoSlider({
		directionNav: true,             // Next & Prev navigation
		controlNav: false,                 // 1,2,3... navigation
	});
});
</script>
</head>

<body >
	<div id="motopress-main" class="main-holder"><!--Begin #motopress-main-->
		<header id="masthead" class="motopress-wrapper site-header" role="banner">
			<div data-motopress-wrapper-file="wrapper/wrapper-header.php" data-motopress-wrapper-type="header" data-motopress-id="<?php echo uniqid() ?>">
				<?php get_template_part('wrapper/wrapper-header'); ?>
			</div>			
		</header>